import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

import Stack from '@mui/material/Stack';

import Card from '../components/cards';
import FormGroup from '../components/form-group';

import { mensagemSucesso, mensagemErro } from '../components/toastr';

import '../custom.css';

import axios from 'axios';
import { BASE_URL } from '../config/axios';

function CadastroAutor() {
    const { idParam } = useParams();

    const navigate = useNavigate();

    const baseURL = `${BASE_URL}/autores`;

    const [id, setId] = useState('');
    const [nome, setNome] = useState('');
    const [citacao, setCitacao] = useState('');
    const [nacionalidade, setNacionalidade] = useState('');

    const [dados, setDados] = React.useState([]);

    function inicializar() {
        if (idParam == null) {
            setId('');
            setNome('');
            setCitacao('');
            setNacionalidade('');
        } else {
            setId(dados.id);
            setNome(dados.nome);
            setCitacao(dados.citacao);
            setNacionalidade(dados.nacionalidade);
        }
    }

    async function salvar() {
        let data = {
            id,
            nome,
            citacao,
            nacionalidade,
        };
        data = JSON.stringify(data);
        if (idParam == null) {
            await axios
                .post(baseURL, data, {
                    headers: { 'Content-Type': 'application/json' },
                })
                .then(function (response) {
                    mensagemSucesso(`Autor ${nome} cadastrado com sucesso!`);
                    navigate(`/listagem-autores`);
                })
                .catch(function (error) {
                    mensagemErro(error.response.data);
                });
        } else {
            await axios
                .put(`${baseURL}/${idParam}`, data, {
                    headers: { 'Content-Type': 'application/json' },
                })
                .then(function (response) {
                    mensagemSucesso(`Autor ${nome} alterado com sucesso!`);
                    navigate(`/listagem-autores`);
                })
                .catch(function (error) {
                    mensagemErro(error.response.data);
                });
        }
    }

    async function buscar() {
        await axios.get(`${baseURL}/${idParam}`).then((response) => {
            setDados(response.data);
        });
        setId(dados.id);
        setNome(dados.nome);
        setCitacao(dados.citacao);
        setNacionalidade(dados.nacionalidade);
    }


    useEffect(() => {
        if (idParam) {
            buscar();
        }
    }, [id]);

    if (!dados) return null;

    return (
        <div className='container'>
            <Card title='Cadastro de Autor'>
                <div className='row'>
                    <div className='col-lg-12'>
                        <div className='bs-component'>
                            <FormGroup label='Nome: *' htmlFor='inputNome'>
                                <input
                                    type='text'
                                    id='inputNome'
                                    value={nome}
                                    className='form-control'
                                    name='nome'
                                    onChange={(e) => setNome(e.target.value)}
                                />
                            </FormGroup>
                            <FormGroup label='Citação: *' htmlFor='inputCitacao'>
                                <input
                                    type='text'
                                    id='inputCitacao'
                                    value={citacao}
                                    className='form-control'
                                    name='citacao'
                                    onChange={(e) => setCitacao(e.target.value)}
                                />
                            </FormGroup>
                            <FormGroup label='Nacionalidade: *' htmlFor='inputNacionalidade'>
                                <input
                                    type='text'
                                    id='inputNacionalidade'
                                    value={nacionalidade}
                                    className='form-control'
                                    name='nacionalidade'
                                    onChange={(e) => setNacionalidade(e.target.value)}
                                />
                            </FormGroup>
                            <Stack spacing={1} padding={1} direction='row'>
                                <button
                                    onClick={salvar}
                                    type='button'
                                    className='btn btn-success'
                                >
                                    Salvar
                                </button>
                                <button
                                    onClick={inicializar}
                                    type='button'
                                    className='btn btn-danger'
                                >
                                    Cancelar
                                </button>
                            </Stack>
                        </div>
                    </div>
                </div>
            </Card>
        </div>
    );
}

export default CadastroAutor;
