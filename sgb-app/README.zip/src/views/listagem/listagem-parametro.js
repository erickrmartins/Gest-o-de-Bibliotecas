import React from 'react';
import Card from '../../components/ui/card.js';
import SubCard from '../../components/ui/sub-card.js';

import '../../custom.css';
import { useNavigate } from 'react-router-dom';

import { mensagemSucesso, mensagemErro } from '../../components/toastr.js';

import Stack from '@mui/material/Stack';
import { IconButton } from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import EditIcon from '@mui/icons-material/Edit';
import True from '@mui/icons-material/CheckCircleOutlineOutlined';
import False from '@mui/icons-material/RadioButtonUncheckedOutlined';

import axios from 'axios';
import { BASE_URL } from '../../config/axios.js';
import ImagemTopo from '../../components/topo-imagem.js';

function ListagemParametro() {
    const navigate = useNavigate();

    const baseURL = `${BASE_URL}/parametros`;

    const [dados, setDados] = React.useState(null);

    React.useEffect(() => {
        axios.get(baseURL)
            .then((response) => {
                setDados(response.data);
            })
            .catch((error) => {
                mensagemErro('Erro ao se conectar ao servidor!');
            });
    }, []);

    return (
        <div>
            <ImagemTopo
                imagem="/background-gerencia.jpg"
                titulo="Listagem de Parâmetros"
                subtitulo="Aqui você pode alterar os parâmetros do sistema."
            />
            <div className="container">
                <Card>
                    <SubCard className="row">
                        <table className="table table-hover">
                            <thead>
                                <tr>
                                    <th scope="col">Prazo Empréstimo</th>
                                    <th scope="col">Limite Empréstimo</th>
                                    <th scope="col">Permitir Renovação</th>
                                    <th scope="col">Renovação com Fila</th>
                                    <th scope="col">Dias Renovação</th>
                                    <th scope="col">Prazo Retirada</th>
                                    <th scope="col">Recomendados</th>
                                    <th scope="col">Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                {dados && dados.map((item) => (
                                    <tr >
                                        <td>{item.prazoEmprestimo}</td>
                                        <td>{item.limiteEmprestimo}</td>
                                        <td>{item.permitirRenovacao ? <True /> : <False />}</td>
                                        <td>{item.renovacaoComFila ? <True /> : <False />}</td>
                                        <td>{item.diasRenovacao}</td>
                                        <td>{item.prazoRetirada}</td>
                                        <td>{item.recomendados}</td>
                                        <td>
                                            <Stack spacing={1} padding={0} direction='row'>
                                                <IconButton
                                                    aria-label='edit'
                                                    onClick={() => navigate(`cadastrar/${item.id}`)}
                                                >
                                                    <EditIcon />
                                                </IconButton>
                                            </Stack>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </SubCard>
                </Card>
            </div>
        </div>
    );
}

export default ListagemParametro;